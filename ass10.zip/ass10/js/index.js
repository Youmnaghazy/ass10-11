var formemail = document.getElementById('formemail');//input
var formpassword = document.getElementById('formpassword');//input
var formname = document.getElementById('formname');
var loginbtn1=document.getElementsByClassName('loginbtn1');
var Signup=document.getElementById('Signup')
var failMessage =document.querySelector(".failMessage");
var successMessage=document.querySelector(".successMessage");
var login =document.getElementById("login");
var signupcontainer ;
if( localStorage.getItem("form")==null ){
    signupcontainer=[];
}
else{
    signupcontainer = JSON.parse(localStorage.getItem("form"));
}
if(Signup != null){
    Signup.addEventListener("click",function(){
    signup()
})
}
function signup(){
    if(formname.value=="" || formemail.value =="" ||formpassword.value ==""){
        failMessage.classList.replace("d-none","d-block");

    }
    else if(formname.value!="" && formemail.value !="" &&formpassword.value !=""){
        failMessage.classList.replace("d-block","d-none");
        var form={
            email:formemail.value,
            password:formpassword.value,
            name:formname.value
        }
        
        signupcontainer.push(form);
        localStorage.setItem("form",JSON.stringify(signupcontainer));
        successMessage.classList.replace("d-none","d-block");
        location.href="index.html";
    }
    
}
if(login != null){
    login.addEventListener("click",function(){
        logIn();
    })
}

function  logIn(){
    if(formemail.value !="" && formpassword.value!=""){
        successMessage.classList.replace("d-block","d-none");
        location.href="thankyou.html"
    }
    else{
      
        successMessage.classList.replace("d-none","d-block");
    }
}





function clearform(){
        ///to reset form
        formemail.value="";
        formpassword.value=""; 
        formname.value="";
}
